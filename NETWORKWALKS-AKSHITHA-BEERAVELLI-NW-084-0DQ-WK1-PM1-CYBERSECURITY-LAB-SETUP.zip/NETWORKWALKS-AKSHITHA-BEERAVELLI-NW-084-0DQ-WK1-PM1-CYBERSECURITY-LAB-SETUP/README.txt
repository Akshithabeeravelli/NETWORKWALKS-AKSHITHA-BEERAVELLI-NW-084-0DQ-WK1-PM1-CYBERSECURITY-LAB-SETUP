NETWORKWALKS | WEEK 1 – PROJECT 1: CYBERSECURITY LAB SETUP

Author: Akshitha Beeravelli
NetworkWalks ID: NW-084-0DQ

Hands-on cybersecurity lab setup using Oracle VM VirtualBox and Kali Linux. Documenting VM configuration, NAT networking, connectivity verification, screenshots, and learning outcomes for NetworkWalks Week 1 – Project 1.

See README.md for the full project documentation and screenshots.
