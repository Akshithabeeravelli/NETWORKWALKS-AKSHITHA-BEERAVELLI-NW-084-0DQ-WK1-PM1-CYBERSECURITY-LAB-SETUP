# NetworkWalks | Week 1 – Project 1: Cybersecurity Lab Setup

A hands-on learning project documenting a cybersecurity lab setup using Oracle VM VirtualBox and Kali Linux.

## Project overview

This repository documents the preparation and initial verification of a Kali Linux virtual machine for the NetworkWalks Cybersecurity Internship, Week 1 – Project 1. The supplied evidence includes the VirtualBox network-adapter settings and a Kali Linux terminal showing successful replies from `8.8.8.8`.

> **Evidence note:** This package contains the two screenshots supplied for this customization. Add any further screenshots, recordings, and configuration outputs only after Akshitha has personally captured or verified them on her system.

## Objectives

- Prepare a virtualization environment using Oracle VM VirtualBox.
- Run Kali Linux as a virtual machine.
- Configure and inspect the VM network adapter.
- Verify outbound IP connectivity from Kali Linux.
- Record the setup, evidence, troubleshooting, and learning outcomes.

## Tools and technologies

| Tool | Purpose |
|---|---|
| Oracle VM VirtualBox | Run and configure the virtual machine |
| Kali Linux | Linux environment for cybersecurity learning |
| Windows host | Host operating system shown in the supplied VirtualBox screenshot |
| GitHub | Project documentation and version control |

## Lab architecture

```text
Windows Host
└── Oracle VM VirtualBox
    └── Kali Linux VM (kali_network_walks)
        └── VirtualBox NAT Network (Network_walks_lab)
```

The screenshot shows Adapter 1 enabled and attached to a NAT Network named `Network_walks_lab`. The Kali terminal screenshot shows replies to `ping 8.8.8.8`. The exact guest IP address, gateway, DNS resolver, VirtualBox version, and Kali release should be recorded from the actual machine rather than assumed.

## Implementation evidence

### 1. VirtualBox network adapter

See [`screenshots/virtualbox/02-virtualbox-nat-network-settings.jpg`](screenshots/virtualbox/02-virtualbox-nat-network-settings.jpg). The supplied image shows:

- VM name: `kali_network_walks`
- Adapter 1: enabled
- Attached to: NAT Network
- NAT Network name: `Network_walks_lab`
- Adapter type shown: Intel PRO/1000 MT Desktop (82540EM)

### 2. Kali Linux connectivity check

See [`screenshots/network/01-kali-linux-connectivity-ping.jpg`](screenshots/network/01-kali-linux-connectivity-ping.jpg). The terminal displays the command `ping 8.8.8.8` and successful ICMP replies. This demonstrates IP-level reachability to that destination at the time of the test. It does not by itself verify DNS resolution or every network service.

### 3. Useful verification commands

Run these on the Kali VM and record the actual output:

```bash
ip a
ip route
cat /etc/resolv.conf
ping -c 4 8.8.8.8
getent hosts kali.org
```

Do not publish example IP addresses as actual configuration unless they match the machine's output.

## Documentation

- [`documentation/environment-details.md`](documentation/environment-details.md) – record host, VM, and software versions.
- [`documentation/network-configuration.md`](documentation/network-configuration.md) – record actual interface, addressing, gateway, DNS, and adapter mode.
- [`documentation/verification-checklist.md`](documentation/verification-checklist.md) – mark tests only after performing them.
- [`documentation/troubleshooting.md`](documentation/troubleshooting.md) – record issues and verified fixes.
- [`documentation/submission-checklist.md`](documentation/submission-checklist.md) – final review before submission.

## Security and ethical use

Use this lab for education and authorized security testing only. Test only systems owned by the student or covered by explicit permission. Keep intentionally vulnerable targets isolated and follow applicable laws and responsible-disclosure practices.

## Author and submission details

- **Author:** Akshitha Beeravelli
- **NetworkWalks ID:** NW-084-0DQ
- **Program:** NetworkWalks Cybersecurity Internship
- **Week:** 1
- **Project:** 1 – Cybersecurity Lab Setup
- **Repository:** `NETWORKWALKS-AKSHITHA-BEERAVELLI-NW-084-0DQ-WK1-PM1-CYBERSECURITY-LAB-SETUP`

## About this repository

Hands-on cybersecurity lab setup using Oracle VM VirtualBox and Kali Linux. Documenting VM configuration, NAT networking, connectivity verification, screenshots, and learning outcomes for NetworkWalks Week 1 – Project 1.

---

**Before submission:** Akshitha should review the documentation, verify every configuration value on her own VM, and add any remaining evidence from her own work. This package does not claim that unshown tasks (such as snapshots, shared folders, or DNS checks) have been completed.
