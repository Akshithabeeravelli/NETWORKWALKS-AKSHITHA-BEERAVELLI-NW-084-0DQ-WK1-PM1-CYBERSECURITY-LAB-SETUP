# Environment Details

Fill in values from Akshitha's actual machine before submission.

| Item | Verified value |
|---|---|
| Host operating system | Windows (shown in supplied screenshot; exact version not confirmed) |
| Host CPU / RAM | To be recorded |
| VirtualBox version | To be recorded |
| VM name | `kali_network_walks` (visible in screenshot) |
| Kali Linux release | To be recorded |
| VM RAM / CPU / disk | To be recorded |
| Snapshot name | To be recorded if created |
