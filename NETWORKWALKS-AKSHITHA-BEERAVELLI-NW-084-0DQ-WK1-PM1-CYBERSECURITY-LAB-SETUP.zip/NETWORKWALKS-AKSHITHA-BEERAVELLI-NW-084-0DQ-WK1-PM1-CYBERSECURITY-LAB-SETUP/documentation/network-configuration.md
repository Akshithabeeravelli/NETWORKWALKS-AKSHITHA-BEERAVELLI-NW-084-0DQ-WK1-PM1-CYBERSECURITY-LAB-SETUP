# Network Configuration

## Settings visible in the supplied evidence

- VirtualBox Adapter 1 is enabled.
- Attachment mode: NAT Network.
- NAT Network name: `Network_walks_lab`.
- Adapter type: Intel PRO/1000 MT Desktop (82540EM).
- Kali terminal screenshot shows successful replies to `ping 8.8.8.8`.

## Record actual guest configuration

Run `ip a`, `ip route`, and `cat /etc/resolv.conf` in Kali and enter the observed values below.

| Field | Actual value |
|---|---|
| Interface name | To be recorded |
| IPv4 address / prefix | To be recorded |
| Default gateway | To be recorded |
| DNS resolver | To be recorded |
| NAT Network IPv4 prefix | To be recorded from VirtualBox |

Do not assume a static address, gateway, or DNS value based only on the ping screenshot.
