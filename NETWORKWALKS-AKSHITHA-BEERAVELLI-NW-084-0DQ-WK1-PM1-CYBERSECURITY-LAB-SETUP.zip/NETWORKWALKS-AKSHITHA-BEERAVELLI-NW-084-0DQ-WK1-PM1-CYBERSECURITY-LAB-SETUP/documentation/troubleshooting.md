# Troubleshooting Log

Record only issues that actually occurred.

| Date | Symptom | Checks performed | Resolution | Verified? |
|---|---|---|---|---|
| | | | | |

## Useful checks

```bash
ip a
ip route
cat /etc/resolv.conf
ping -c 4 8.8.8.8
getent hosts kali.org
```
