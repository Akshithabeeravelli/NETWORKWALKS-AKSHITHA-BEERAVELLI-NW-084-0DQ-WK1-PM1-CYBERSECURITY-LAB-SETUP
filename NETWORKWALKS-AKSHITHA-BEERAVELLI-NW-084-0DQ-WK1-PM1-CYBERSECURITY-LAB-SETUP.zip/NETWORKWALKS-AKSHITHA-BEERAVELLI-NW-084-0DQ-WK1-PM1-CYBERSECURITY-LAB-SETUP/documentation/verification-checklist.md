# Verification Checklist

Mark a task complete only after personally checking it on the VM.

- [x] VirtualBox Adapter 1 is enabled and attached to NAT Network (visible in supplied screenshot).
- [x] Kali terminal shows successful replies to `ping 8.8.8.8` (visible in supplied screenshot).
- [ ] Record `ip a` output and verify the guest IPv4 address.
- [ ] Record `ip route` output and verify the default route.
- [ ] Verify DNS resolution with `getent hosts kali.org` or `nslookup kali.org`.
- [ ] Confirm the NAT Network IPv4 prefix in VirtualBox Network settings.
- [ ] Create and verify a recovery snapshot, if required by the assignment.
- [ ] Add any other required screenshots captured by Akshitha.
