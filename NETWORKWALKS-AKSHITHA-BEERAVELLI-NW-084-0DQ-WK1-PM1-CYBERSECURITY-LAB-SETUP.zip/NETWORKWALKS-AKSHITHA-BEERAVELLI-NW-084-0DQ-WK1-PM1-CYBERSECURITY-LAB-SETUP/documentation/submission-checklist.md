# Submission Checklist

- [ ] Confirm author name and NetworkWalks ID.
- [ ] Confirm the repository title and About description.
- [ ] Review all configuration values against the actual VM.
- [ ] Add remaining screenshots required by the assignment.
- [ ] Add a practical demonstration video only if Akshitha recorded it herself and it is required.
- [ ] Remove placeholders and mark only verified tasks complete.
- [ ] Check that README image links render on GitHub.
- [ ] Confirm the repository is public if the internship submission requires public access.
